import "./CardTestimoni3.css";

const CardTestimoni3 = () => {
  return (
    <div className="cardtestimoni">
      <div className="bg-quote">
        <div className="bg-quote-child" />
      </div>
      <img
        className="layer-liaison-icon"
        loading="lazy"
        alt=""
        src="/ellipse-5@2x.png"
      />
      <div className="lorem-ipsum-dolor3">{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut lacus, auctor pretium ac ultrices. Dui lacus dignissim tincidunt urna, at enim tempo. Pellentesque amet Lorem ipsum dolor sit amet, `}</div>
      <div className="comfortable-and-met">
        Comfortable and met all my expectations! I ordered a medium and it fit
        perfectly
      </div>
      <b className="anisa-zahra">Anisa Zahra</b>
      <div className="founder-milenial">Founder milenial</div>
    </div>
  );
};

export default CardTestimoni3;
