import "./CardTestimoni1.css";

const CardTestimoni1 = () => {
  return (
    <div className="cardtestimoni2">
      <div className="bg-quote2">
        <div className="bg-quote-inner" />
      </div>
      <div className="comfortable-and-met-all-my-exp-container">
        <div className="comfortable-and-met2">
          I really love this shirt! It feels more like a light flannel than a
          jacket
        </div>
      </div>
      <div className="lorem-ipsum-dolor-sit-amet-co-frame">
        <div className="lorem-ipsum-dolor5">{`Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut lacus, auctor pretium ac ultrices. Dui lacus dignissim tincidunt urna, at enim tempo. Pellentesque amet Lorem ipsum dolor sit amet, `}</div>
      </div>
      <div className="cardtestimoni-inner">
        <div className="frame-parent2">
          <div className="ellipse-wrapper">
            <img className="ellipse-icon" alt="" src="/ellipse-5-2@2x.png" />
          </div>
          <div className="anisa-zahra-parent">
            <b className="anisa-zahra2">Melissa Wallace</b>
            <div className="founder-milenial-wrapper">
              <div className="founder-milenial2">Founder milenial</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CardTestimoni1;
